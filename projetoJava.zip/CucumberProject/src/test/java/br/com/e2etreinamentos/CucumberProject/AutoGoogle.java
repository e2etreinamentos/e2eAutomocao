package br.com.e2etreinamentos.CucumberProject;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutoGoogle {

	WebDriver driver; 
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();	
		driver.get("https://www.google.com/");
	}

	
	@Test 
	public void testexto() {
		
		
		WebElement pesquisar = driver.findElement(By.name("q"));
		pesquisar.sendKeys("Anderson Lindo");
		pesquisar.click();
		
	}
	
	
	@After
	public void tearDown() throws Exception {
	}


}
