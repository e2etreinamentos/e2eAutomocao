package br.com.e2etreinamentos.CucumberProject;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalcTest {

	Calc c = new Calc();
	
	@Test
	public void test() {
		assertEquals(2, c.soma(1, 1));
		int resultado = c.soma(1, 1);
		
		
		if (resultado == 2) {
			System.out.println("Resultado " + resultado+ " OK");
		}else {
			System.out.println("Resultado " + resultado + " errado");
		}
	}

}
