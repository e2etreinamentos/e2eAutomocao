package br.com.e2etreinamentos.CucumberProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExampleSteps {

	WebDriver driver;

	@Given("^eu quero acessar o google$")
	public void eu_quero_acessar_o_google() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://www.google.com.br");

	}

	@When("^digitar um \"(.*?)\"$")
	public void digitar_um(String arg1) throws Throwable {
	

	}

	@Then("^retorno o site$")
	public void retorno_o_site() throws Throwable {
		
	}

}
