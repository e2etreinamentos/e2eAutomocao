package br.com.e2etreinamentos.CucumberProject;

public class Calc {

	public int soma(int num1, int num2) {

		return num1 + num2;
	}

	public int dividir(int num1, int num2) {

		return num1 / num2;
	}

	public int multiplicar(int num1, int num2) {

		return num1 * num2;
	}

	public int subtrair(int num1, int num2) {

		return num1 - num2;
	}
}
